<?php

require_once "../modelo/ManejadorCategoria.php";

$manejador = new ManejadorCategoria();
$datos = $manejador->obtenerListaCategoria();

require_once "../vista/categoria_consultar.php";

?>