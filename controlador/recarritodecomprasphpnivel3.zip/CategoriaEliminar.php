<?php

require_once "../modelo/ManejadorCategoria.php";

$manejador = new ManejadorCategoria();

if ((isset($_POST['opcion'])) && ($_POST['opcion'] == '1')){

	$nu_categoria=$_POST["nu_categoria"];

	$operacionValida=$manejador->eliminarCategoria($nu_categoria);
	if ($operacionValida)
		$mensaje="Eliminaci�n exitosa";
	else
		$mensaje="Error durante la eliminaci�n";

}

$datos = $manejador->obtenerListaCategoria();

require_once "../vista/categoria_consultar.php";

?>