<?php

require_once "../modelo/ManejadorCategoria.php";

if ((isset($_POST['opcion'])) && ($_POST['opcion'] == '1')){
	
	$nu_categoria=$_POST["nu_categoria"];
	$nb_categoria=$_POST["nb_categoria"];

	$categoria= new Categoria();

	$categoria->setNu_categoria($nu_categoria);
	$categoria->setNb_categoria($nb_categoria);

	$manejador = new ManejadorCategoria();
	$operacionValida = $manejador->insertarCategoria($categoria);

	if($operacionValida)
		$mensaje="Datos ingresados satisfactoriamente";
	else
		$mensaje="Error en par�metros";

}

require_once "../vista/categoria_ingresar.php";

?>