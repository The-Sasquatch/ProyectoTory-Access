<?php

require_once "../modelo/ManejadorCategoria.php";

$manejador = new ManejadorCategoria();

if(isset($_POST['opcion']))
	$opcion=$_POST['opcion'];
else
	$opcion="0";

if($opcion=="2"){

	$nu_categoria=$_POST["nu_categoria"];
	$categoria=$manejador->buscarCategoria($nu_categoria);

	$nu_categoria=$categoria->getNu_categoria();
	$nb_categoria=$categoria->getNb_categoria();

}else if($opcion=="1"){

	$nu_categoria=$_POST["nu_categoria"];
	$nb_categoria=$_POST["nb_categoria"];

	$categoria = new Categoria();

	$categoria->setNu_categoria($nu_categoria);
	$categoria->setNb_categoria($nb_categoria);

	$operacionValida=$manejador->modificarCategoria($categoria);

	if($operacionValida)
		$mensaje="Datos modificados satisfactoriamente";
	else
		$mensaje="Error en par�metros";

}

require_once "../vista/categoria_modificar.php";

?>