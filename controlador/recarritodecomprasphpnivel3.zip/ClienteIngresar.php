<?php

session_start();

require_once "../modelo/ManejadorCliente.php";

$manejador = new ManejadorCliente();

if ((isset($_POST['opcion'])) && ($_POST['opcion'] == '1')){
	
	$nu_cliente=$_POST["nu_cliente"];
	$nb_cliente=$_POST["nb_cliente"];
	$co_correo=$_POST["co_correo"];
	$co_clave=$_POST["co_clave"];
	$nu_cedula=$_POST["nu_cedula"];

	$cliente = new Cliente();

	$cliente->setNu_cliente($nu_cliente);
	$cliente->setNb_cliente($nb_cliente);
	$cliente->setCo_correo($co_correo);
	$cliente->setCo_clave($co_clave);
	$cliente->setNu_cedula($nu_cedula);

	$operacionValida = $manejador->insertarCliente($cliente);

	if($operacionValida){
		
		$condicion = "co_correo = '$co_correo'";
		$clientes = $manejador->obtenerListaCliente($condicion);
		
		$cliente = $clientes[0];
		$_SESSION['nu_cliente'] = $cliente->getNu_cliente();
		$_SESSION['nb_cliente'] = $cliente->getNb_cliente();
		$_SESSION['co_correo'] = $cliente->getCo_correo();
		
		$mensaje="Bienvenido al sistema, haga click en catalogo para comenzar";
	}else{
		$mensaje="Error en par�metros";
	}

}

require_once "../vista/cliente_ingresar.php";

?>