<?php

session_start();

require_once "../modelo/ManejadorCarrito.php";
require_once "../modelo/ManejadorCompra.php";
require_once "../modelo/ManejadorDetalle_compra.php";
require_once "../modelo/ManejadorProducto.php";

$man_carrito = new ManejadorCarrito();
$man_compra = new ManejadorCompra();
$man_detalle = new ManejadorDetalle_compra();
$man_producto = new ManejadorProducto();

$nu_cliente = $_SESSION['nu_cliente'];
$condicion = "nu_cliente = $nu_cliente";


if(isset($_POST['opcion'])){

	$opcion = $_POST['opcion'];

	// eliminar producto del carrito
	if($opcion == 2){
		
		$nu_producto = $_POST['nu_producto'];
		
		$man_carrito->eliminarCarrito($nu_cliente, $nu_producto);
		
	}else
	// ingresar producto en detalle_compra
	if($opcion == 1){
		
		$nu_producto = $_POST['nu_producto'];
		$ca_producto = $_POST['ca_producto'];
		
		// tratamiento de la compra
		$cond = "nu_cliente = $nu_cliente and in_despacho = 'A'";
		$compras = $man_compra->obtenerListaCompra($cond);
		if(count($compras) == 0){
			
			// agraegar una compra NUEVA!!
			$compra = new Compra();
			$compra->setNu_cliente($nu_cliente);
			$compra->setIn_despacho("A");
			
			$man_compra->insertarCompra($compra);

			// busca la ultima compra con la misma condicion anterior
			$compras = $man_compra->obtenerListaCompra($cond);
		}

		$compra = $compras[0];
		$nu_compra = $compra->getNu_compra();
		
		$detalle_compra = new Detalle_compra();
		$detalle_compra->setNu_compra($nu_compra);
		$detalle_compra->setNu_producto($nu_producto);
		$detalle_compra->setCa_producto($ca_producto);
		
		$man_detalle->insertarDetalle_compra($detalle_compra);
		
		// eliminar producto del carrito
		$man_carrito->eliminarCarrito($nu_cliente,$nu_producto);
		
		// actualizar inventario
		$producto = $man_producto->buscarProducto($nu_producto);
		$ca_existencia = $producto->getCa_existencia();
		$ca_existencia = $ca_existencia - $ca_producto;
		$producto->setCa_existencia($ca_existencia);
		
		$man_producto->modificarProducto($producto);
		
	}

}

$datos = $man_carrito->obtenerListaCarrito($condicion);

require_once "../vista/carrito_consultar.php";

?>
