<?php

session_start();

require_once "../modelo/ManejadorProducto.php";
require_once "../modelo/ManejadorCategoria.php";
require_once "../modelo/ManejadorCarrito.php";

$manejador = new ManejadorProducto();
$man_categoria = new ManejadorCategoria();
$man_carrito = new ManejadorCarrito();

$nu_categoria = "";
$condicion = "1=1";

if(isset($_POST['nu_categoria']) && $_POST['nu_categoria'] != ""){
	$nu_categoria = $_POST['nu_categoria'];
	$condicion = "nu_categoria = $nu_categoria";
}


// agregar producto al carrito
if(isset($_POST['opcion'])){

	$nu_cliente = $_SESSION['nu_cliente'];
	$hoy = date("m/d/Y");

	$opcion = $_POST['opcion'];
	if($opcion == 1){
		
		$carrito = new Carrito();
		$carrito->setNu_cliente($nu_cliente);
		$carrito->setNu_producto($_POST['nu_producto']);
		$carrito->setFe_registro($hoy);
		
		$man_carrito->insertarCarrito($carrito);
		
	}
}

// filtrar los prodctos con los incluidos en el carrito
if(isset($_SESSION['nu_cliente'])){
	$nu_cliente = $_SESSION['nu_cliente'];
	$condicion .= " AND nu_producto NOT IN " .
		"(SELECT nu_producto FROM carrito WHERE nu_cliente = $nu_cliente)";
}

$cbo_nu_categoria = $man_categoria->comboCategoria($nu_categoria);

$datos = $manejador->obtenerListaProducto($condicion);

require_once "../vista/catalogo_consultar.php";

?>
