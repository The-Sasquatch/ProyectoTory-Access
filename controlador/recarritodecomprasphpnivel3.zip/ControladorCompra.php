<?php

session_start();

require_once "../modelo/ManejadorDetalle_compra.php";
require_once "../modelo/ManejadorCompra.php";

$man_detalle = new ManejadorDetalle_compra();
$man_compra = new ManejadorCompra();

$nu_cliente = $_SESSION['nu_cliente'];
$condicion = "nu_cliente = $nu_cliente AND in_despacho = 'A'";

$hoy = date("Y") . "/" . date("m") . "/" . date("d");

if(isset($_POST['opcion'])){
	
	$opcion = $_POST['opcion'];
	if($opcion == '99'){

		$nu_compra = $_POST['nu_compra'];
		$in_despacho = $_POST['in_despacho'];
		
		$compra = new Compra();
		$compra->setNu_compra($nu_compra);
		$compra->setNu_cliente($nu_cliente);
		$compra->setIn_despacho($in_despacho);
		$compra->setFe_despacho($hoy);
		
		$man_compra->modificarCompra($compra);
	}
	
}


$datos = $man_detalle->obtenerListaDetalle_compra($condicion);

require_once "../vista/detalle_compra_consultar.php";

?>
