<?php

require_once "../vista/index.php";

?>