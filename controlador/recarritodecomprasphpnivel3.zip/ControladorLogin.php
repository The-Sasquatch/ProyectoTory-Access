<?php

session_start();

require_once "../modelo/ManejadorCliente.php";

$manejador = new ManejadorCliente();

if ((isset($_POST['opcion'])) && ($_POST['opcion'] == '1')){
	
	$co_correo=$_POST["co_correo"];
	$co_clave=$_POST["co_clave"];
	
	$condicion = "co_correo = '$co_correo' AND co_clave = '$co_clave'";

	$resultado = $manejador->obtenerListaCliente($condicion);

	if(count($resultado) > 0){
		
		$ciente = $resultado[0];
		$_SESSION['nu_cliente'] = $ciente->getNu_cliente();
		$_SESSION['nb_cliente'] = $ciente->getNb_cliente();
		$_SESSION['co_correo'] = $ciente->getCo_correo();
		$mensaje="Bienvenido al sistema, haga click en catalogo para comenzar";
		
	}else{
		$mensaje="Error en par�metros";
	}

}

require_once "../vista/cliente_login.php";

?>