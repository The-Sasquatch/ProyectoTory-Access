<?php

session_start();

require_once "../modelo/ManejadorProducto.php";
require_once "../modelo/ManejadorCategoria.php";

$manejador = new ManejadorProducto();
$man_categoria = new ManejadorCategoria();


// destruir parametros de SESSION
$_SESSION['nb_cliente']  = "";
$_SESSION['co_correo']  = "";

unset($_SESSION['nb_cliente']);
unset($_SESSION['co_correo']);

session_destroy();


$cbo_nu_categoria = $man_categoria->comboCategoria();

$datos = $manejador->obtenerListaProducto();

require_once "../vista/catalogo_consultar.php";

?>