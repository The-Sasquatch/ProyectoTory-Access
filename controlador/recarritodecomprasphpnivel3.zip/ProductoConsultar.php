<?php

require_once "../modelo/ManejadorProducto.php";

$manejador = new ManejadorProducto();
$datos = $manejador->obtenerListaProducto();

require_once "../vista/producto_consultar.php";

?>