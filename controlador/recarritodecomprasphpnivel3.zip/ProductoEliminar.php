<?php

require_once "../modelo/ManejadorProducto.php";

$manejador = new ManejadorProducto();

if ((isset($_POST['opcion'])) && ($_POST['opcion'] == '1')){

	$nu_producto=$_POST["nu_producto"];

	$operacionValida=manejadorProducto->eliminarProducto($nu_producto);
	if ($operacionValida)
		$mensaje="Eliminaci�n exitosa";
	else
		$mensaje="Error durante la eliminaci�n";
}

$datos = $manejador->listar();

require_once "../vista/producto_consultar.php";

?>