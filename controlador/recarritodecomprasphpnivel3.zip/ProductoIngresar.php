<?php

require_once "../modelo/ManejadorProducto.php";
require_once "../modelo/ManejadorCategoria.php";

$nu_categoria = "";
$nb_imagen = "";

if ((isset($_POST['opcion'])) && ($_POST['opcion'] == '1')){
	
	$nu_producto=$_POST["nu_producto"];
	$nb_producto=$_POST["nb_producto"];
	$ca_existencia=$_POST["ca_existencia"];
	$va_precio=$_POST["va_precio"];
	$nu_categoria=$_POST["nu_categoria"];
	$de_producto=$_POST["de_producto"];
	$nb_imagen=$_POST["nb_imagen"];
	
	if(isset($_FILES['nb_imagen'])){

		//datos del arhivo
		$nombre_archivo = $_FILES['nb_imagen']['name'];
		$tipo_archivo = $_FILES['nb_imagen']['type'];
		$tamano_archivo = $_FILES['nb_imagen']['size'];
		
		// indicador de todo bien
		$todo_bien = FALSE;
		$ruta = "../productos";

		//compruebo si las caracter�sticas del archivo son las que deseo
		if (!((strpos($tipo_archivo, "jpg") || strpos($tipo_archivo, "jpeg") || strpos($tipo_archivo, "png")) && ($tamano_archivo < 100000))) {
			$mensaje="Error en par�metros - Se permiten archivos jpeg, jpg o png, con un tama�o de 100 Kb m�ximo";
		}else{
			if (move_uploaded_file($_FILES['nb_imagen']['tmp_name'],  $ruta . "/" . $nombre_archivo)){
				$nb_imagen=$nombre_archivo;
				$todo_bien = TRUE;
			}else{
				$mensaje="Error en par�metros - no se pudo subir el archivo";
				$nb_imagen = "Sin imagen.png";
			}
		}

	}
		
	
	$producto= new Producto();

	$producto->setNu_producto($nu_producto);
	$producto->setNb_producto($nb_producto);
	$producto->setCa_existencia($ca_existencia);
	$producto->setVa_precio($va_precio);
	$producto->setNu_categoria($nu_categoria);
	$producto->setDe_producto($de_producto);
	$producto->setNb_imagen($nb_imagen);

	$manejador = new ManejadorProducto();

	$operacionValida = $manejador->insertarProducto($producto);

	if($operacionValida)
		$mensaje="Datos ingresados satisfactoriamente";
	else
		$mensaje="Error en par�metros";

}

$manCategoria = new ManejadorCategoria();
$cbo_nu_categoria = $manCategoria->comboCategoria($nu_categoria);

require_once "../vista/producto_ingresar.php";

?>