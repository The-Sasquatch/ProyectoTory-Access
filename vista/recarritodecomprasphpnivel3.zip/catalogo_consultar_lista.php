<?php
$txt = "";
$col = 0;

for($x=0; $x<count($datos); $x++){

	if($col == 0){
		$txt .= "\n<div class='w3-row w3-padding-32'>";
	}

	$item = $datos[$x];
	$nu_producto = $item->getNu_producto();
	$nb_producto = $item->getNb_producto();
	$nb_categoria = $item->getCategoria()->getNb_categoria();
	$ca_existencia = $item->getCa_existencia();
	$va_precio = $item->getVa_precio();
	$nb_imagen = $imagen = "../productos/" . $item->getNb_imagen();
	$formulario = "form" . $nu_producto;

	$txt .= "\n<div class='w3-third w3-padding'>";
	$txt .= "\n<div class='w3-padding w3-light-grey w3-border'>";
	$txt .= "\n<p class='w3-center'><img src='$nb_imagen' class='w3-image' style='height:120px;'></p>";

	$txt .= "\n<div class='w3-padding w3-white'>";
	$txt .= "\n<p><b>$nb_producto</b><br>";
	$txt .= "\n$nb_producto<br>";
	$txt .= "\nCantidad: $ca_existencia<br>Precio: $va_precio<br>";
	$txt .= "\nCategoria: $nb_categoria</p>";
	
	if(isset($_SESSION['co_correo'])){
		$txt .= "\n<form name='$formulario' action='" . $_SERVER['PHP_SELF'] . "' method='post'>";
		$txt .= "\n<input name='opcion' type='hidden' value='1'>";
		$txt .= "\n<input name='nu_producto' type='hidden' value='$nu_producto'>";
		$txt .= "\n<div class='w3-center'>";
		$txt .= "\n<div class='w3-center w3-padding w3-button w3-hover-blue'>";
		$txt .= "\n<img src='../imagenes/carrito_mas.png' class='w3-image' style='width:40px;' onClick='submit()'>";
		$txt .= "\n</div>";
		$txt .= "\n</div>";
		$txt .= "\n</form>";
	}
		
	$txt .= "\n</div>";

	$txt .= "\n</div>";
	$txt .= "\n</div>";

	$col++;
	if($col == 3 || $x == count($datos)-1){
		$txt .= "\n</div>";
		$col = 0;
	}

}

echo $txt;

?>

<?php
?>
