
<div class='w3-container w3-padding'>
	<div class='w3-center'>
	<a href='../controlador/CategoriaIngresar.php' title='Permite ingresar un registro en la base de datos'><img src='../imagenes/add.png' alt='Ingresar icono' class='w3-image' style='width:32px;'></a>
	&nbsp;
	<a href='../controlador/CategoriaConsultar.php' title='Permite listar los datos de la base de datos'><img src='../imagenes/list.png' alt='Listar icono' class='w3-image' style='width:32px;'></a>
	</div>
</div>