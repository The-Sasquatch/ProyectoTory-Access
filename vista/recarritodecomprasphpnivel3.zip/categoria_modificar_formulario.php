
<div class='w3-padding'>

	<div class='w3-card-4'>
		<div class='w3-container w3-indigo'>
		<p class='w3-center'>Modifique los datos en el formulario y presione Aceptar</p>
		</div>
	</div>

	<form name='categoria_modificar' method='post' action="CategoriaModificar.php" >
		<input name='opcion' type='hidden' value='1'>
		<input name='nu_categoria' type='hidden' value='<?php echo $nu_categoria; ?>'>

		<p>
		<label>Categoria</label>
		<input name='nb_categoria' value='<?php echo $nb_categoria; ?>' maxlength='50' type='text' class='w3-input w3-border'>
		</p>

		<p class='w3-center'>
		<input name='aceptar' value='Aceptar' type='button' class='w3-btn w3-light-grey' onClick='validar(document.categoria_modificar)' >
		</p>
	</form>

	<p class="w3-center w3-text-red">
		<?php echo $mensaje; ?>
	</p>

</div>