
<div class='w3-padding'>
	<div class='w3-card-4'>
		<div class='w3-container w3-indigo'>
		<p class='w3-center'>Ingrese los datos en el formulario y presione Aceptar</p>
		</div>
	</div>

<form name='cliente_ingresar' method='post' action="ClienteIngresar.php" >
<input name='opcion' type='hidden' value='1'>
<input name='nu_cliente' type='hidden' value='<?php echo $nu_cliente; ?>'>

	<p>
	<label>Cedula</label>
	<input name='nu_cedula' value='<?php echo $nu_cedula; ?>' maxlength='15' type='number' class='w3-input w3-border'>
	</p>

	<p>
	<label>Nombre del Cliente</label>
	<input name='nb_cliente' value='<?php echo $nb_cliente; ?>' maxlength='50' type='text' class='w3-input w3-border'>
	</p>

	<p>
	<label>correo</label>
	<input name='co_correo' value='<?php echo $co_correo; ?>' maxlength='50' type='email' class='w3-input w3-border'>
	</p>

	<p>
	<label>clave</label>
	<input name='co_clave' value='<?php echo $co_clave; ?>' maxlength='15' type='password' class='w3-input w3-border'>
	</p>

	<p class='w3-center'>
	<input name='aceptar' value='Aceptar' type='button' class='w3-btn w3-indigo' onClick='validar(document.cliente_ingresar)' >
	</p>

</form>

	<p class='w3-center'>
	<?php echo $mensaje; ?> 
	</p>

</div>

