<?php

if(count($datos) > 0){
	
	$detalle_compra = $datos[0];
	$nu_compra = $detalle_compra->getNu_compra();
	$fe_registro = $detalle_compra->getFe_registro();
	$fe_registro = date_format(date_create($fe_registro),"d/m/Y");
	
?>

	<table class='w3-table-all' style='width:90%; margin:auto; '>
		<tr class="w3-indigo">
			<th>Fecha de Compra</th>
			<th>Estatus</th>
			<th class="w3-center">Accion</th>
		</tr>
		<tr>
			<td><?php echo $fe_registro; ?></td>
			<td>En Proceso</td>
			<td class="w3-center">
			<form name="formpagar" action="ControladorCompra.php" method="post">
			<input name="nu_compra" value="<?php echo $nu_compra; ?>" type="hidden">
			<input name="in_despacho" value="C" type="hidden">
			<input name="opcion" value="99" type="hidden">
			</form>
			<form name="formdespachar" action="ControladorCompra.php" method="post">
			<input name="nu_compra" value="<?php echo $nu_compra; ?>" type="hidden">
			<input name="in_despacho" value="D" type="hidden">
			<input name="opcion" value="99" type="hidden">
			</form>
			
			<a href="javascript:document.formpagar.submit()" class="w3-btn w3-blue">Pagada</a>
			<a href="javascript:document.formdespachar.submit()" class="w3-btn w3-blue">Despachada</a>
			</td>
		</tr>
	</table>
	
	<p class="w3-center w3-large"><b>Detalle de la Compra</b></p>

<?php
}
?>

<table class='w3-table-all' style='width:90%; margin:auto; '>
	<tr class="w3-indigo">
		<th class="w3-center">#</th>
		<th>Producto</th>
		<th class="w3-center">Cantidad</th>
		<th class="w3-center">Precio</th>
		<th class="w3-center">Subtotal</th>
		<th class="w3-center">Fecha de Registro</th>
	</tr>


<?php
$fila=1;
$total = 0;
for($x=0; $x<count($datos); $x++){
	$item = $datos[$x];
	$ca_producto = $item->getCa_producto();
	$va_precio = $item->getProducto()->getVa_precio();
	$subtotal = (int)$ca_producto * (int)$va_precio;
	$total += $subtotal;
	$fe_registro = $item->getFe_registro();
	$fe_registro = date_format(date_create($fe_registro),"d/m/Y");
?>

	<tr>
		<td class="w3-center"><?php echo $fila; ?></td>
		<td><?php echo $item->getProducto()->getNb_producto(); ?></td>
		<td class="w3-center"><?php echo $ca_producto; ?></td>
		<td class="w3-right-align">
		<?php echo number_format($va_precio, 2, ',', '.'); ?>
		</td>
		<td class="w3-right-align">
		<?php echo number_format($subtotal, 2, ',', '.'); ?>
		</td>
		<td class="w3-center"><?php echo $fe_registro; ?></td>
	</tr>

<?php
	$fila++;
}
?>
	<tr class="w3-indigo">
		<td>&nbsp;</td>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
		<td class="w3-right-align"><b>Total ===></td>
		<td class="w3-right-align"><b><?php echo number_format($total, 2, ',', '.'); ?></b></td>
		<td>&nbsp;</td>
	</tr>

</table>
