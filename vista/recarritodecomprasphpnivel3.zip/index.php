<!DOCTYPE HTML>
<html>
<head>
<title>Carrito Online</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../css/w3.css" rel="stylesheet" type="text/css">
<script language='javascript' src='../js/jquery-3.5.1.js'></script>
</head>

<body>

<?php
include "tope_index.php";


include "menu.php";


include "piedepagina.php";
?>

</body>
</html>
