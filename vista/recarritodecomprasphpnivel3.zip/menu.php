
<div class='w3-bar w3-light-grey'>

<a href='../controlador/CategoriaConsultar.php' class='w3-bar-item w3-button w3-hover-blue'>Categoria</a>
<a href='../controlador/ProductoConsultar.php' class='w3-bar-item w3-button w3-hover-blue'>Producto</a>
<a href='../controlador/ClienteConsultar.php' class='w3-bar-item w3-button w3-hover-blue'>Cliente</a>
<a href='../controlador/CarritoConsultar.php' class='w3-bar-item w3-button w3-hover-blue'>Carrito</a>
<a href='../controlador/CompraConsultar.php' class='w3-bar-item w3-button w3-hover-blue'>Compra</a>

</div>
