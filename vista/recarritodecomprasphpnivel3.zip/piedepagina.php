
<div class="w3-dark-gray w3-card-4">

	<div class="w3-row">

		<div class="w3-half">
		<p class="w3-center w3-text-orange"><b>Dise&ntilde;o y Programaci&oacute;n Web: Douglas Barrios</b></p>
		</div>

		<div class="w3-half">
		<p class="w3-center w3-text-sand">2021 &copy; Todos los derechos reservados</p>
		</div>

	</div>

</div>
