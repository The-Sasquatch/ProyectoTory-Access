


<table class='w3-table-all' style='width:90%; margin:auto; '>
<tr class="w3-indigo">
	<th>#</th>
	<th width="30%">Producto</th>
	<th width="15%">Cantidad</th>
	<th width="15%">Precio</th>
	<th width="15%">Imagen</th>
	<th>Acci&oacute;n</th>
</tr>

<?php
$fila=0;

for($x=0; $x<count($datos); $x++) {
	$item = $datos[$x];
	$imagen = "../productos/" . $item->getNb_imagen();
	//echo "imagen=$imagen";
?>

<?php
$fila++;
?>

<tr>
	<td><?php echo ($x+1); ?></td>
	<td><?php
	echo $item->getNb_producto() . "<br>" . $item->getDe_producto() .
	"<br>Categoria: " . $item->getCategoria()->getNb_categoria();
	?></td>
	<td><?php echo $item->getCa_existencia(); ?></td>
	<td><?php echo $item->getVa_precio(); ?></td>
	<td class="w3-center">
	<img src="<?php echo $imagen ?>" style="height=64px;" class="w3-image">
	</td>
	
	<form name='formupdate<?php echo $fila; ?>' action='../controlador/ProductoModificar.php' method='post'>
	<input name='opcion' type='hidden' value='2'>
	<input name='nu_producto' type='hidden' value='<?php echo $item->getNu_producto(); ?>' >
	</form>
	
	<form name='formdelete<?php echo $fila; ?>' action='../controlador/ProductoEliminar.php' method='post'>
	<input name='opcion' type='hidden' value='1'>
	<input name='nu_producto' type='hidden' value='<?php echo $item->getNu_producto(); ?>' >
	</form>
	
	<td>
	<p class="w3-padding">
	<a href='javascript:document.formupdate<?php echo $fila; ?>.submit();'><img src='../imagenes/edit.png' alt='Modificar icono' class='w3-image' style='width:32px;'></a>
	&nbsp;
	<a href='javascript:if(confirm("�Est� de acuerdo con la acci�n ingresada?")) document.formdelete<?php echo $fila; ?>.submit();'><img src='../imagenes/delete.png' alt='Modificar icono' class='w3-image' style='width:32px;'></a>
	</p>
	</td>
</tr>

<?php } ?>


</table>


