
<div class="w3-grey">
<img src="imagenes/banner.png" class="w3-image w3-card-4" style="width:100%; " alt="Imagen de fondo">
</div>
